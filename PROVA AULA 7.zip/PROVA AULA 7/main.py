import random

lancar_dados = random.randint(1, 6)

num1 = (lancar_dados)
num2 = lancar_dados

print(f"A da soma dos dois numeros aleatorios é {num1 + num2}.")